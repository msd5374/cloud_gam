package com.example.websocketdemo.constants;

public interface AppConstants {
}
