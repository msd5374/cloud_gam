package com.example.websocketdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebsocketDemoApplication {

	public static void main(String[] args) {

		SpringApplication.run(WebsocketDemoApplication.class, args);
	}
}

/*

spring.security.user.name =root
		spring.security.user.password=root
		spring.security.user.roles=user
*/


